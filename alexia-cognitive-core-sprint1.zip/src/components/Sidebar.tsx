// This file is no longer needed as we've moved to bottom navigation
// Keeping empty to prevent import errors, but can be deleted
export default function Sidebar() {
  return null;
}
